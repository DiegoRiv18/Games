Outlaw Pursuit Controls

A/D - move right/ left
W/Space - jump
1 - Switch to Orange (no ability, average speed + can use gun)
2 - Switch to Blue (heal ability, slow speed + can use gun)
3 - Switch to Yellow (shield ability, fast speed + cannot use gun)
E - Use ability (abilities described above and are applied to entire party. Ie, shield applies to everyone.)
mouse - Aim
left click - Shoot
R - Begin to reload gun manually (gun will automatically reload when out of ammo)
F - Open Shop (only available upon reaching shop-- prompt will appear on screen when available)
B - Open Bulletin (only available upon reaching bulletin-- prompt will appear on screen when available)
	- Click on the next bounty to set the horse to next destination. Then interact with horse to go to next destination.

There is currently no way to quit the game besides the main menu. Please use alt + f4 when done.